<div class="copy">
                        <p> &copy; 2018 KPIMS. All Rights Reserved | Design by <a href="#" target="_blank">KPIMS</a> </p>
</div>
